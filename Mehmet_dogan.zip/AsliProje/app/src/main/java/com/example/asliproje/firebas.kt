package com.example.asliproje

import com.google.firebase.auth.FirebaseAuth

fun loginWithFirebase(
    email: String,
    password: String,
    onSuccess: () -> Unit,
    onError: (String) -> Unit
) {
    FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password)
        .addOnSuccessListener { onSuccess() }
        .addOnFailureListener { e -> onError(e.localizedMessage ?: "Hata oluştu") }
}
