package com.example.asliproje

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun VRProjectDetailsScreen() {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Text(
            text = "VR Projesi: Hareket Analizi ve Doğruluk Kontrol Sistemi",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Start
        )

        Text(
            text = "Bu proje, sanal gerçeklik (VR) ortamında gerçekleştirilen fiziksel hareketlerin doğruluğunu analiz eden bir sistem geliştirmeyi amaçlamaktadır. MediaPipe kullanılarak kullanıcıların iskelet verileri gerçek zamanlı takip edilmekte ve yapılan hareketlerin hedef hareketlerle uyumluluğu ölçülmektedir.",
            fontSize = 16.sp
        )


        SectionTitle("Kullanılan Teknolojiler")
        BulletList(
            listOf(
                "MediaPipe: Hafif, mobil uyumlu, gerçek zamanlı pose analizi.",
                "Jetpack Compose: Modern Android arayüzü.",
                "Firebase: Giriş işlemleri ve kullanıcı yönetimi.",
                "Emülatör & Gerçek Cihaz Testi: Farklı ortam senaryoları için testler."
            )
        )


        SectionTitle("Proje İşleyişi")
        NumberedList(
            listOf(
                "Kullanıcı giriş yaparak simülasyonu başlatır.",
                "MediaPipe ile iskelet hareketleri analiz edilir.",
                "Doğruluk oranı hesaplanır.",
                "Geri bildirim sunularak gelişim takip edilir."
            )
        )


        SectionTitle("Projenin Hedefleri")
        BulletList(
            listOf(
                "Eğitim ortamlarında hareket doğruluğunun dijital olarak analiz edilmesi.",
                "Kullanıcıya sayısal ve görsel geri bildirim sunulması.",
                "Sağlık, spor ve eğitim alanlarında düşük maliyetli sistem."
            )
        )


        SectionTitle("Gelecek Planları")
        BulletList(
            listOf(
                "MediaPipe verileri ile zaman serisi analizleri.",
                "OpenGL ile 3D görselleştirme.",
                "Kişiye özel egzersiz raporları ve planlar."
            )
        )
    }
}


@Composable
fun SectionTitle(text: String) {
    Text(
        text = text,
        fontSize = 18.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(top = 8.dp)
    )
}


@Composable
fun BulletList(items: List<String>) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items.forEach {
            Text(text = "• $it", fontSize = 16.sp)
        }
    }
}


@Composable
fun NumberedList(items: List<String>) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items.forEachIndexed { index, item ->
            Text(text = "${index + 1}. $item", fontSize = 16.sp)
        }
    }
}
