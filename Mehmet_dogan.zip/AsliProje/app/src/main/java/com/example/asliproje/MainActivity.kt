package com.example.asliproje

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.navigation.compose.rememberNavController
import com.example.asliproje.ui.theme.AsliProjeTheme
import com.google.firebase.FirebaseApp


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            AsliProjeTheme {
                val navController = rememberNavController()
                FirebaseApp.initializeApp(this)
                AppNavigation(navController)


            }
        }
    }
}
